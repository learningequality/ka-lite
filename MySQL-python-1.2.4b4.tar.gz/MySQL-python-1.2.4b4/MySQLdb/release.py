
__author__ = "Andy Dustman <farcepest@gmail.com>"
version_info = (1,2,4,'beta',4)
__version__ = "1.2.4b4"
